import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Login from './component/Login/Login.js';
import Nav from './component/Nav/Nav.js';
import VSBoard from './component/VSBoard/VSBoard.js';
import Freeboard from './component/Freeboard/Freeboard.js';
import Hotboard from './component/Hotboard/Hotboard.js';



function App() {
  return (
    // 메인 페이지 구성
    // 네비바와 푸터를 작성해주고 나머지는 컴포넌트로 구성한다.
    // 메인 페이지에 들어갈 컴포넌트의 구성으로는 실시간으로 Top 3을 보여주는 게시글 컴포넌트
    // 이 사이트는 사이트 이용자가 어떠한 주제에 대하여 글을 작성하고 선택지는 두개 혹은 3개로 주어지고
    // 이 사이트를 이용하는 사람들이 투표를 하여 가장 많은 표를 받은 글이 Top 3에 올라가게 된다.
    // 투표는 진행바를 통하여 100% 백분율에서 투표수만큼 진행바가 변경되도록 한다.
    // 투표를 하기 위해서는 회원가입이 필요하며 로그인을 하여야 한다.
    // 로그인을 하지 않은 상태에서는 투표를 할 수 없다.
    // 로그인을 하지 않은 상태에서는 글을 작성할 수 없다.
    // 코드 작성
    <BrowserRouter>
    <div className="App">
    <Nav />
    
      <Routes>
        <Route path="/" element={<Main />} /> {/* 메인 페이지 변경 */}
        <Route path="/Hotboard" element={<Hotboard />} />
        <Route path="/VSboard" element={<VSBoard />} />
        <Route path="/Freeboard" element={<Freeboard />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    <div>
    
    </div>
    </div>
    </BrowserRouter>
  );
}

function Main() {
  return (
    <div>
      <h1>메인 페이지</h1>
    </div>
  );
}


export default App;