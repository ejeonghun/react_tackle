import { Link } from 'react-router-dom';
import React from 'react';
import './Nav.css';
import LottieAnimation from '../Lottie/Lottie';

function Nav() {
    return (
        <div>
        <div className="nav_bar">
            <Link className="NavMenu" to="/"><LottieAnimation /></Link>
            <Link className="NavMenu" to="/login">로그인</Link>
        </div>
        <div className='search'>
            <input type='text' placeholder='검색어를 입력하세요' />
        </div>
        <div className="nav">
            
            <Link className="NavMenu" to="/Hotboard"><b>HOT 게시판</b></Link>
            <Link className="NavMenu" to="/VSboard"><b>찬반 게시판</b></Link>
            <Link className="NavMenu" to="/Freeboard"><b>자유 게시판</b></Link>
            
        </div>
        </div>
    );
}

export default Nav;